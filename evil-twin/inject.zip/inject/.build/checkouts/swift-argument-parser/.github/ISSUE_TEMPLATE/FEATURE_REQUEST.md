---
name: 💡 Feature Request
about: A suggestion for a new feature
---

<!--
    Thanks for contributing to the Swift Argument Parser!

    Before you submit your issue, please replace the paragraph
    below with information about your proposed feature.
-->

Replace this paragraph with a description of your proposed feature. Code samples that show what's missing, or what new capabilities will be possible, are very helpful! Provide links to existing issues or external references/discussions, if appropriate.