# ``ArgumentParser/ArgumentArrayParsingStrategy``

## Topics

### Parsing Strategies

- ``remaining``
- ``allUnrecognized``
- ``postTerminator``
- ``captureForPassthrough``

### Deprecated

- ``unconditionalRemaining``
