# ``ArgumentParser/OptionGroup``

## Topics

### Creating an Option Group

- ``init(title:visibility:)``

### Option Group Properties

- ``title``

### Infrequently Used APIs

- ``init()``
- ``init(from:)``
- ``wrappedValue``
- ``description``


