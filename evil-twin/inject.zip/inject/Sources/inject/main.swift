Inject.main()
