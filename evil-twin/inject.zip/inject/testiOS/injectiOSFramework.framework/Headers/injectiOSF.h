//
//  TestInject.h
//  TestInject
//
//  Created by admin on 2021/11/29.
//

#import <Foundation/Foundation.h>

//! Project version number for TestInject.
FOUNDATION_EXPORT double injectiOSFrameworkVersionNumber;

//! Project version string for TestInject.
FOUNDATION_EXPORT const unsigned char injectiOSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestInject/PublicHeader.h>


